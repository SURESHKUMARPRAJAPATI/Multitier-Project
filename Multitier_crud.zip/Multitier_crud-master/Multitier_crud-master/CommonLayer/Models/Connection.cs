﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonLayer.Models
{
    public class Connection
    {
        public static string Connectionstr { get; set; }
    }
}
